package L14_ExerciseDefiningClasses.Task02_CompanyRoster;

import java.util.List;

public class Department {
    private List<Employee> departmentList = null;
}
