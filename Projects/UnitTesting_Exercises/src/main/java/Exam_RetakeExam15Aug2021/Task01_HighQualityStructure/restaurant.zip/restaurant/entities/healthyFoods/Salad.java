package restaurant.entities.healthyFoods;

public class Salad extends Food{
    private static final int PORTION_SIZE = 150;
    public Salad(String name, double price) {
        super(name, PORTION_SIZE, price);
    }
}
